package me.pgb.a2021_03_17_radio.models;

public class RadioStation {

    private String name;
    private String country;
    private String imglink;
    private String streamlink;

    public RadioStation(String streamlink, String name, String country, String imglink){
        this.streamlink = streamlink;
        this.name = name;
        this.country = country;
        this.imglink = imglink;
    }

    public String getName(){
        return name;
    }

    public String getImage(){
        return imglink;
    }

    public String getStream() {
        return streamlink;
    }
}
