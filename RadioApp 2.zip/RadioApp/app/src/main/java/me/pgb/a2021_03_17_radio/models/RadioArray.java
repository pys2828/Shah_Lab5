package me.pgb.a2021_03_17_radio.models;

public class RadioArray {
    private static String[] arr;

    public static RadioStation[] stations = {
            new RadioStation("http://stream.whus.org:8000/whusfm", "WHUS", "USA", "https://i2.wp.com/whus.org/wp-content/uploads/2020/03/whus.png?resize=500%2C400&ssl=1"),
            new RadioStation("http://162.244.80.106:11011/stream", "WBIM", "USA", "https://static-media.streema.com/media/cache/49/c3/49c370260069c46971c0ce48483bba20.jpg"),
            new RadioStation("http://node-21.zeno.fm/5dyp73rrqwzuv?rj-ttl=5&rj-tok=AAABeM58qBUASIAHuWgMVvH91A", "Candlelight and Wine", "USA", "https://imgproxy.zenomedia.com/insecure/fit/500/500/ce/0/plain/https://proxy.zeno.fm/content/stations/agxzfnplbm8tc3RhdHNyMgsSCkF1dGhDbGllbnQYgICQuMuAqgoMCxIOU3RhdGlvblByb2ZpbGUYgICQ-L7HzAkMogEEemVubw/image/%3Fresize=500x500&v=1"),
    };

    public static String[] getRadioNames() {
        arr = new String[stations.length];
        for (int i = 0; i < stations.length; i++){
            arr[i] = stations[i].getName();
        }
        return arr;
    }

    public static String[] getRadioLink(){
        arr = new String[stations.length];
        for (int i = 0; i < stations.length; i++){
            arr[i] = stations[i].getStream();
        }
        return arr;
    }

    public static String[] getRadioImg(){
        arr = new String[stations.length];
        for (int i = 0; i < stations.length; i++){
            arr[i] = stations[i].getImage();
        }
        return arr;
    }

}


